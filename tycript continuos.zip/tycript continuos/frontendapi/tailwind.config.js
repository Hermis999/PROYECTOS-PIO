/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}", // Ajusta si cambian las rutas de tus archivos
    ],
    theme: {
        extend: {},
    },
    plugins: [],
}